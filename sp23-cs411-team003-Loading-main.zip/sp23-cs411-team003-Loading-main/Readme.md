# Team003-Loading
This is a CS411 project repository for team003 for Spring 2023.

# Final Demo Video
https://youtu.be/W8EyeO1uGJo

## Code Contribution
Kelly - Database Design, ER Diagram, Relation Schema, Index Analysis
<br>
Tony - Front-end application, Database Implementation
<br>
Brandon - Store Procedure, Trigger, Database Implementation

